// Question 3 - Login Validation

// Entered username and password
let username = "Fatima";
let password = "12345";

// Correct username and password
let correctUsername = "Fatima";
let correctPassword = "111111";

// Check login details
if (username === correctUsername && password === correctPassword) {
    console.log("Login Successful");
}
else {
    console.log("Invalid Username or Password");
}
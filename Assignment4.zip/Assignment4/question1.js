// Question 1 - JavaScript Operators

// Two number variables
let num1 = 20;
let num2 = 5;

// Arithmetic Operators
console.log("Arithmetic Operators:");

console.log("Addition:", num1 + num2);
console.log("Subtraction:", num1 - num2);
console.log("Multiplication:", num1 * num2);
console.log("Division:", num1 / num2);
console.log("Modulus:", num1 % num2);

// Increment
let incrementNum = num1;
incrementNum++;
console.log("Increment:", incrementNum);

// Decrement
let decrementNum = num1;
decrementNum--;
console.log("Decrement:", decrementNum);


// Assignment Operators
console.log("Assignment Operators:");

let value = 10;

console.log("Original value:", value);

value += 5;
console.log("After += 5:", value);

value -= 3;
console.log("After -= 3:", value);

value *= 2;
console.log("After *= 2:", value);

value /= 4;
console.log("After /= 4:", value);


// Comparison Operators
console.log("Comparison Operators:");

console.log("num1 == num2:", num1 == num2);
console.log("num1 === num2:", num1 === num2);
console.log("num1 != num2:", num1 != num2);
console.log("num1 !== num2:", num1 !== num2);
console.log("num1 > num2:", num1 > num2);
console.log("num1 < num2:", num1 < num2);
console.log("num1 >= num2:", num1 >= num2);
console.log("num1 <= num2:", num1 <= num2);
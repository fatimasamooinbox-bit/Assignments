// Question 4 - Ternary Operator

let age = 18;

let result = age >= 18 ? "Eligible to Vote" : "Not Eligible to Vote";

console.log("Age:", age);
console.log(result);
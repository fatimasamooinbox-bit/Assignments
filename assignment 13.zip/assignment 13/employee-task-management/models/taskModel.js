
const tasks = require("../data/tasks");

// 1. Get all tasks
const getAllTasks = () => {
    return tasks;
};

// 2. Get task by ID
const getTaskById = (id) => {
    return tasks.find(task => task.id === Number(id));
};

// 3. Create new task
const createTask = (taskData) => {
    const newTask = {
        id: tasks.length > 0
            ? Math.max(...tasks.map(task => task.id)) + 1
            : 1,
        ...taskData
    };

    tasks.push(newTask);
    return newTask;
};

// 4. Update complete task
const updateTask = (id, updatedData) => {
    const index = tasks.findIndex(
        task => task.id === Number(id)
    );

    if (index === -1) {
        return null;
    }

    tasks[index] = {
        id: Number(id),
        ...updatedData
    };

    return tasks[index];
};

// 5. Update selected fields
const patchTask = (id, updatedData) => {
    const task = tasks.find(
        task => task.id === Number(id)
    );

    if (!task) {
        return null;
    }

    Object.assign(task, updatedData);
    return task;
};

// 6. Delete task
const deleteTask = (id) => {
    const index = tasks.findIndex(
        task => task.id === Number(id)
    );

    if (index === -1) {
        return null;
    }

    return tasks.splice(index, 1)[0];
};

// 7. Get task summary
const getTaskSummary = () => {
    return {
        totalTasks: tasks.length,
        pending: tasks.filter(
            task => task.status === "Pending"
        ).length,
        inProgress: tasks.filter(
            task => task.status === "In Progress"
        ).length,
        completed: tasks.filter(
            task => task.status === "Completed"
        ).length
    };
};

// 8. Get tasks by employee
const getTasksByEmployee = (name) => {
    return tasks.filter(
        task =>
            task.assignedTo.toLowerCase() === name.toLowerCase()
    );
};

// 9. Get overdue tasks
const getOverdueTasks = () => {
    const today = new Date().toISOString().split("T")[0];

    return tasks.filter(
        task =>
            task.dueDate < today &&
            task.status !== "Completed"
    );
};

// Export all functions
module.exports = {
    getAllTasks,
    getTaskById,
    createTask,
    updateTask,
    patchTask,
    deleteTask,
    getTaskSummary,
    getTasksByEmployee,
    getOverdueTasks
};

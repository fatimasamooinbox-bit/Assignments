
const express = require("express");
const router = express.Router();

const taskController = require("../controllers/taskController");

// Additional challenge routes FIRST
router.get("/summary", taskController.getTaskSummary);
router.get("/overdue", taskController.getOverdueTasks);
router.get("/employee/:name", taskController.getTasksByEmployee);

// Filtering routes
router.get("/status/:status", (req, res, next) => {
    try {
        const status = req.params.status;
        const allowed = ["Pending", "In Progress", "Completed"];

        if (!allowed.includes(status)) {
            return res.status(400).json({
                success: false,
                message: "Invalid status"
            });
        }

        const tasks = require("../models/taskModel")
            .getAllTasks()
            .filter(task => task.status === status);

        res.status(200).json({
            success: true,
            count: tasks.length,
            data: tasks
        });
    } catch (error) {
        next(error);
    }
});

router.get("/priority/:priority", (req, res, next) => {
    try {
        const priority = req.params.priority;
        const allowed = ["Low", "Medium", "High"];

        if (!allowed.includes(priority)) {
            return res.status(400).json({
                success: false,
                message: "Invalid priority"
            });
        }

        const tasks = require("../models/taskModel")
            .getAllTasks()
            .filter(task => task.priority === priority);

        res.status(200).json({
            success: true,
            count: tasks.length,
            data: tasks
        });
    } catch (error) {
        next(error);
    }
});

// Basic CRUD routes
router.get("/", taskController.getAllTasks);
router.get("/:id", taskController.getTaskById);
router.post("/", taskController.createTask);
router.put("/:id", taskController.updateTask);
router.patch("/:id", taskController.patchTask);
router.delete("/:id", taskController.deleteTask);

module.exports = router;

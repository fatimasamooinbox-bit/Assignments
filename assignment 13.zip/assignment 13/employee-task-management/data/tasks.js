
const tasks = [
    {
        id: 1,
        title: "Complete Website Design",
        description: "Design the company website homepage",
        assignedTo: "Ayesha",
        priority: "High",
        status: "In Progress",
        dueDate: "2026-11-20"
    },
    {
        id: 2,
        title: "Prepare Project Report",
        description: "Prepare the monthly project report",
        assignedTo: "Ali",
        priority: "Medium",
        status: "Pending",
        dueDate: "2026-11-25"
    },
    {
        id: 3,
        title: "Fix Login Bug",
        description: "Resolve the login authentication issue",
        assignedTo: "Sara",
        priority: "High",
        status: "Completed",
        dueDate: "2026-11-15"
    },
    {
        id: 4,
        title: "Update Database",
        description: "Update employee records",
        assignedTo: "Ahmed",
        priority: "Low",
        status: "Pending",
        dueDate: "2026-11-30"
    },
    {
        id: 5,
        title: "Test Application",
        description: "Perform application testing",
        assignedTo: "Ayesha",
        priority: "Medium",
        status: "In Progress",
        dueDate: "2026-11-19"
    }
];

module.exports = tasks;


const taskModel = require("../models/taskModel");

// Allowed values
const priorities = ["Low", "Medium", "High"];
const statuses = ["Pending", "In Progress", "Completed"];

const allowedFields = [
    "title",
    "description",
    "assignedTo",
    "priority",
    "status",
    "dueDate"
];

// Validate task data
const validateTask = (data, isPartial = false) => {
    const errors = [];

    if (!data || typeof data !== "object" || Array.isArray(data)) {
        return ["Request body must be a JSON object"];
    }

    if (!isPartial) {
        allowedFields.forEach(field => {
            if (data[field] === undefined ||
                data[field] === null ||
                data[field] === "") {
                errors.push(`${field} is required`);
            }
        });
    }

    Object.keys(data).forEach(field => {
        if (!allowedFields.includes(field)) {
            errors.push(`Invalid field: ${field}`);
        }
    });

    const stringFields = [
        "title",
        "description",
        "assignedTo"
    ];

    stringFields.forEach(field => {
        if (data[field] !== undefined &&
            (typeof data[field] !== "string" ||
            !data[field].trim())) {
            errors.push(`${field} must be a non-empty string`);
        }
    });

    if (data.priority !== undefined &&
        !priorities.includes(data.priority)) {
        errors.push("Priority must be Low, Medium, or High");
    }

    if (data.status !== undefined &&
        !statuses.includes(data.status)) {
        errors.push("Status must be Pending, In Progress, or Completed");
    }

    if (data.dueDate !== undefined) {
        const validDate = /^\d{4}-\d{2}-\d{2}$/.test(data.dueDate) &&
            !Number.isNaN(Date.parse(data.dueDate)) &&
            new Date(data.dueDate).toISOString().slice(0, 10) === data.dueDate;

        if (!validDate) {
            errors.push("dueDate must be a valid date in YYYY-MM-DD format");
        }
    }

    return errors;
};

// GET all tasks
const getAllTasks = (req, res, next) => {
    try {
        res.status(200).json({
            success: true,
            data: taskModel.getAllTasks()
        });
    } catch (error) {
        next(error);
    }
};

// GET task by ID
const getTaskById = (req, res, next) => {
    try {
        const task = taskModel.getTaskById(req.params.id);

        if (!task) {
            return res.status(404).json({
                success: false,
                message: "Task not found"
            });
        }

        res.status(200).json({
            success: true,
            data: task
        });
    } catch (error) {
        next(error);
    }
};

// POST create task
const createTask = (req, res, next) => {
    try {
        const errors = validateTask(req.body);

        if (errors.length > 0) {
            return res.status(400).json({
                success: false,
                errors
            });
        }

        const newTask = taskModel.createTask(req.body);

        res.status(201).json({
            success: true,
            message: "Task created successfully",
            data: newTask
        });
    } catch (error) {
        next(error);
    }
};

// PUT update complete task
const updateTask = (req, res, next) => {
    try {
        const errors = validateTask(req.body);

        if (errors.length > 0) {
            return res.status(400).json({
                success: false,
                errors
            });
        }

        const updatedTask = taskModel.updateTask(
            req.params.id,
            req.body
        );

        if (!updatedTask) {
            return res.status(404).json({
                success: false,
                message: "Task not found"
            });
        }

        res.status(200).json({
            success: true,
            message: "Task updated successfully",
            data: updatedTask
        });
    } catch (error) {
        next(error);
    }
};

// PATCH update selected fields
const patchTask = (req, res, next) => {
    try {
        const errors = validateTask(req.body, true);

        if (errors.length > 0 || Object.keys(req.body || {}).length === 0) {
            return res.status(400).json({
                success: false,
                errors: errors.length ? errors : ["Provide at least one field"]
            });
        }

        const updatedTask = taskModel.patchTask(
            req.params.id,
            req.body
        );

        if (!updatedTask) {
            return res.status(404).json({
                success: false,
                message: "Task not found"
            });
        }

        res.status(200).json({
            success: true,
            message: "Task updated successfully",
            data: updatedTask
        });
    } catch (error) {
        next(error);
    }
};

// DELETE task
const deleteTask = (req, res, next) => {
    try {
        const deletedTask = taskModel.deleteTask(req.params.id);

        if (!deletedTask) {
            return res.status(404).json({
                success: false,
                message: "Task not found"
            });
        }

        res.status(200).json({
            success: true,
            message: "Task deleted successfully",
            data: deletedTask
        });
    } catch (error) {
        next(error);
    }
};

// GET task summary
const getTaskSummary = (req, res, next) => {
    try {
        res.status(200).json({
            success: true,
            data: taskModel.getTaskSummary()
        });
    } catch (error) {
        next(error);
    }
};

// GET tasks by employee
const getTasksByEmployee = (req, res, next) => {
    try {
        const tasks = taskModel.getTasksByEmployee(req.params.name);

        res.status(200).json({
            success: true,
            count: tasks.length,
            data: tasks
        });
    } catch (error) {
        next(error);
    }
};

// GET overdue tasks
const getOverdueTasks = (req, res, next) => {
    try {
        const tasks = taskModel.getOverdueTasks();

        res.status(200).json({
            success: true,
            count: tasks.length,
            data: tasks
        });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    getAllTasks,
    getTaskById,
    createTask,
    updateTask,
    patchTask,
    deleteTask,getTaskSummary,
getTasksByEmployee,
getOverdueTasks
};

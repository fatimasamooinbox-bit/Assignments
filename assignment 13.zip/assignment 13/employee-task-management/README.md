
# Employee Task Management REST API

## Project Description
This project is a REST API built using Node.js and Express.js.
It manages employee tasks using CRUD operations and follows
the MVC (Model-View-Controller) architecture.

## Technologies Used
- Node.js
- Express.js
- JavaScript
- dotenv
- Nodemon
- Postman

## Project Structure
employee-task-management/
- data/
- models/
- controllers/
- routes/
- middleware/
- app.js
- server.js
- .env
- package.json
- README.md

## Installation

1. Install Node.js.
2. Open the project folder in VS Code.
3. Open the terminal.
4. Install dependencies:

   npm install

## Run the Project

Development mode:

   npm run dev

Normal mode:

   npm start

The server runs on:

http://localhost:3000

## API Endpoints

### Task CRUD
- GET /api/tasks
- GET /api/tasks/:id
- POST /api/tasks
- PUT /api/tasks/:id
- PATCH /api/tasks/:id
- DELETE /api/tasks/:id

### Filtering
- GET /api/tasks/status/:status
- GET /api/tasks/priority/:priority

### Additional Challenges
- GET /api/tasks/summary
- GET /api/tasks/employee/:name
- GET /api/tasks/overdue

## Features
- Create, read, update and delete tasks.
- Filter tasks by status and priority.
- Find tasks assigned to an employee.
- View task summary.
- Find overdue tasks.
- Validate task data.
- Centralized error handling.
- Handle unknown routes.

## Data Storage
Tasks are stored in an in-memory JavaScript array.
Data resets when the server restarts.

## Testing
All API endpoints were tested using Postman.


const express = require("express");

const app = express();

// Import routes and middleware
const bookRoutes = require("./routes/bookRoutes");
const notFound = require("./middleware/notFound");
const errorHandler = require("./middleware/errorHandler");

// Middleware to read JSON data
app.use(express.json());

// Welcome route
app.get("/", (req, res) => {
    res.status(200).json({
        success: true,
        message: "Welcome to Library Management API"
    });
});

// Book routes
app.use("/api/books", bookRoutes);

// Handle unknown routes
app.use(notFound);

// Handle application errors
app.use(errorHandler);

module.exports = app;

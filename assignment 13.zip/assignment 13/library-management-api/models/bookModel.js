
const books = require("../data/books");

// 1. Get all books
const getAllBooks = () => {
    return books;
};

// 2. Get book by ID
const getBookById = (id) => {
    return books.find(book => book.id === Number(id));
};

// 3. Add a new book
const createBook = (bookData) => {
    const newBook = {
        id: books.length > 0
            ? Math.max(...books.map(book => book.id)) + 1
            : 1,
        ...bookData
    };

    books.push(newBook);
    return newBook;
};

// 4. Update a book
const updateBook = (id, updatedData) => {
    const index = books.findIndex(
        book => book.id === Number(id)
    );

    if (index === -1) {
        return null;
    }

    books[index] = {
        id: Number(id),
        ...updatedData
    };

    return books[index];
};

// 5. Delete a book
const deleteBook = (id) => {
    const index = books.findIndex(
        book => book.id === Number(id)
    );

    if (index === -1) {
        return null;
    }

    return books.splice(index, 1)[0];
};

// 6. Search books by title
const searchBooksByTitle = (title) => {
    return books.filter(book =>
        book.title.toLowerCase().includes(title.toLowerCase())
    );
};

// 7. Get available books
const getAvailableBooks = () => {
    return books.filter(book => book.available === true);
};

// Export all functions
module.exports = {
    getAllBooks,
    getBookById,
    createBook,
    updateBook,
    deleteBook,
    searchBooksByTitle,
    getAvailableBooks
};

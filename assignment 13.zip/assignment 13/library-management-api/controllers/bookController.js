
const bookModel = require("../models/bookModel");

// Validate book data
const validateBook = (data) => {
    const errors = [];

    if (!data || typeof data !== "object" || Array.isArray(data)) {
        return ["Request body must be a JSON object"];
    }

    const requiredFields = [
        "title",
        "author",
        "category",
        "publishedYear",
        "available"
    ];

    requiredFields.forEach(field => {
        if (data[field] === undefined || data[field] === null) {
            errors.push(`${field} is required`);
        }
    });

    if (typeof data.title !== "string" || !data.title.trim()) {
        errors.push("Title must be a non-empty string");
    }

    if (typeof data.author !== "string" || !data.author.trim()) {
        errors.push("Author must be a non-empty string");
    }

    if (typeof data.category !== "string" || !data.category.trim()) {
        errors.push("Category must be a non-empty string");
    }

    if (
        !Number.isInteger(data.publishedYear) ||
        data.publishedYear < 1 ||
        data.publishedYear > new Date().getFullYear()
    ) {
        errors.push("Published year must be a valid year");
    }

    if (typeof data.available !== "boolean") {
        errors.push("Available must be true or false");
    }

    return errors;
};

// GET all books
const getAllBooks = (req, res, next) => {
    try {
        const books = bookModel.getAllBooks();

        res.status(200).json({
            success: true,
            count: books.length,
            data: books
        });
    } catch (error) {
        next(error);
    }
};

// GET book by ID
const getBookById = (req, res, next) => {
    try {
        const book = bookModel.getBookById(req.params.id);

        if (!book) {
            const error = new Error("Book not found");
            error.statusCode = 404;
            throw error;
        }

        res.status(200).json({
            success: true,
            data: book
        });
    } catch (error) {
        next(error);
    }
};

// CREATE book
const createBook = (req, res, next) => {
    try {
        const errors = validateBook(req.body);

        if (errors.length > 0) {
            const error = new Error(errors.join(", "));
            error.statusCode = 400;
            throw error;
        }

        const newBook = bookModel.createBook(req.body);

        res.status(201).json({
            success: true,
            message: "Book created successfully",
            data: newBook
        });
    } catch (error) {
        next(error);
    }
};

// UPDATE book
const updateBook = (req, res, next) => {
    try {
        const errors = validateBook(req.body);

        if (errors.length > 0) {
            const error = new Error(errors.join(", "));
            error.statusCode = 400;
            throw error;
        }

        const updatedBook = bookModel.updateBook(
            req.params.id,
            req.body
        );

        if (!updatedBook) {
            const error = new Error("Book not found");
            error.statusCode = 404;
            throw error;
        }

        res.status(200).json({
            success: true,
            message: "Book updated successfully",
            data: updatedBook
        });
    } catch (error) {
        next(error);
    }
};

// DELETE book
const deleteBook = (req, res, next) => {
    try {
        const deletedBook = bookModel.deleteBook(req.params.id);

        if (!deletedBook) {
            const error = new Error("Book not found");
            error.statusCode = 404;
            throw error;
        }

        res.status(200).json({
            success: true,
            message: "Book deleted successfully",
            data: deletedBook
        });
    } catch (error) {
        next(error);
    }
};

// SEARCH books by title
const searchBooksByTitle = (req, res, next) => {
    try {
        const books = bookModel.searchBooksByTitle(req.query.title || "");

        res.status(200).json({
            success: true,
            count: books.length,
            data: books
        });
    } catch (error) {
        next(error);
    }
};

// GET available books
const getAvailableBooks = (req, res, next) => {
    try {
        const books = bookModel.getAvailableBooks();

        res.status(200).json({
            success: true,
            count: books.length,
            data: books
        });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    getAllBooks,
    getBookById,
    createBook,
    updateBook,
    deleteBook,
    searchBooksByTitle,
    getAvailableBooks
};

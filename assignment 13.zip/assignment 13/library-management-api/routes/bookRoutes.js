
const express = require("express");
const router = express.Router();

const bookController = require("../controllers/bookController");

// Specific routes must come before /:id

// Search books by title
router.get("/search", bookController.searchBooksByTitle);

// Get available books
router.get("/available", bookController.getAvailableBooks);

// Get all books
router.get("/", bookController.getAllBooks);

// Get book by ID
router.get("/:id", bookController.getBookById);

// Add a new book
router.post("/", bookController.createBook);

// Update a book
router.put("/:id", bookController.updateBook);

// Delete a book
router.delete("/:id", bookController.deleteBook);

module.exports = router;

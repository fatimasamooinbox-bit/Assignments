
const books = [
    {
        id: 1,
        title: "The Alchemist",
        author: "Paulo Coelho",
        category: "Fiction",
        publishedYear: 1988,
        available: true
    },
    {
        id: 2,
        title: "Atomic Habits",
        author: "James Clear",
        category: "Self-Help",
        publishedYear: 2018,
        available: true
    },
    {
        id: 3,
        title: "Rich Dad Poor Dad",
        author: "Robert Kiyosaki",
        category: "Finance",
        publishedYear: 1997,
        available: false
    },
    {
        id: 4,
        title: "Harry Potter",
        author: "J.K. Rowling",
        category: "Fantasy",
        publishedYear: 1997,
        available: true
    },
    {
        id: 5,
        title: "Think and Grow Rich",
        author: "Napoleon Hill",
        category: "Self-Help",
        publishedYear: 1937,
        available: false
    }
];

module.exports = books;

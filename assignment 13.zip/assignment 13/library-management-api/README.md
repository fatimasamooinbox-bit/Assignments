
# Library Management REST API

## Project Description
A REST API developed using Node.js and Express.js to manage
library books. The project follows MVC architecture and uses
an in-memory array for storing book records.

## Technologies Used
- Node.js
- Express.js
- JavaScript
- dotenv
- Nodemon
- Postman

## Installation

Install dependencies:

npm install

## Run the Project

Development mode:

npm run dev

Normal mode:

npm start

Server URL:

http://localhost:3001

## API Endpoints

### CRUD Operations
- GET /api/books
- GET /api/books/:id
- POST /api/books
- PUT /api/books/:id
- DELETE /api/books/:id

### Additional Features
- GET /api/books/search?title=Harry
- GET /api/books/available

## Features
- View all books.
- Find a book by ID.
- Add new books.
- Update book information.
- Delete books.
- Search books by title.
- Filter available books.
- Validate book data.
- Centralized error handling.
- Handle unknown routes.

## Data Storage
Books are stored in an in-memory JavaScript array.
Data resets when the server restarts.

## Testing
API endpoints are tested using Postman.
